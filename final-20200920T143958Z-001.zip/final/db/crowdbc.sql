/*
SQLyog Ultimate v11.11 (32 bit)
MySQL - 5.5.11 : Database - crowdbc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`crowdbc` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `crowdbc`;

/*Table structure for table `blockchain` */

DROP TABLE IF EXISTS `blockchain`;

CREATE TABLE `blockchain` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `previos` varchar(333) DEFAULT NULL,
  `current` varchar(333) DEFAULT NULL,
  `data` varchar(333) DEFAULT NULL,
  `timastamp` varchar(333) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `blockchain` */

insert  into `blockchain`(`id`,`previos`,`current`,`data`,`timastamp`) values (1,'0','6d4afb79a929db08c5f36ebeebc9d5ced4518e16419934df04c3c0b11ffcbcca','https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox','1583929289296'),(2,'6d4afb79a929db08c5f36ebeebc9d5ced4518e16419934df04c3c0b11ffcbcca','504545069788e3764c7b733bdcb1a65da9940af60a53483da442e05303550402','https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox','1583929360231'),(3,'504545069788e3764c7b733bdcb1a65da9940af60a53483da442e05303550402','c894c314817f48ff6c756f0585b958576f41041e54589f6fb8d984372b2e23df','https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox','1583929415142'),(4,'c894c314817f48ff6c756f0585b958576f41041e54589f6fb8d984372b2e23df','76298a8788b05c8a9d26e06d2c05a56856cff5df0514de5a53c034a127153814','https://scikit-learn/scikit-learn/issues/4808','1583936385930'),(5,'76298a8788b05c8a9d26e06d2c05a56856cff5df0514de5a53c034a127153814','01664bf467890e618481a7f3873b8af41beb729492f00c258f073932a1327afa','https://issues/4808','1583936717500');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `cpwd` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `unique1` varchar(1000) NOT NULL,
  `amount` varchar(50) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

/*Data for the table `register` */

insert  into `register`(`id`,`name`,`pwd`,`cpwd`,`role`,`unique1`,`amount`) values (1,'sa','sa','sa','worker','0','0'),(2,'sangee','asa','asa','worker','0','0'),(3,'sangees','sd','sds','0','0','0'),(4,'sa','dsfg','bsfgdsfgs','requester','4cf6829aa93728e8f3c97df913fb1bfa95fe5810e2933a05943f8312a98d9cf2','1000'),(5,'sa','dsfg','bsfgdsfgs','requester','4cf6829aa93728e8f3c97df913fb1bfa95fe5810e2933a05943f8312a98d9cf2','1000'),(6,'Admin','Admin','Admin','requester','c1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6f','1000'),(7,'mehhaa','mehhaa','mehhaa','requester','527bbb56e3970dd54f9fca3645049e1668b30febb70c6aa5730523b0c47a6af3','940'),(8,'mallaa','mallaa','mallaa','worker','ef59ad943a8e8ce4eb15968e7bd50cefa8f0236a60c92c8a78583c3402ce6a78','1000'),(9,'mathi','mathi','mathi','worker','cbf9095c85e5b6448bed6aba4d1c5f09f2b49926cb80463e7c6976b5e8b15540','1000'),(10,'bala','bala','bala','worker','f2fdd58856e77152463d6183ffa198d69bb241ddf8378734c4d074f74544f4c8','1000'),(11,'jeeva','jeeva','jeeva','worker','e0aac11b76e6ba2e2850268d30529db9ee86750254cafa9aab7812bb0c59ee5','1000'),(12,'meennaa','meennaa','meennaa','worker','e6144337c993c7dc71d1b6142626c3f389b9f77aad9f0de2eb2e1ab2f7258eb9','1000'),(13,'jas','jas','jas','worker','94fbbc949203f3aefd570029b15dc91c1eff906b53393c68416f0732599c126','960'),(14,'mahila','mahila','mahila','requester','63abb17fdd37edb557b465e0cd05ca4e968d8b8c8ac527a111f45b956405e033','700'),(15,'Bharathi','Bharathi','Bharathi','worker','fe4c0587374171c39248e618f50e775e5790c5250faf09dba8f288345683b365','1700');

/*Table structure for table `task` */

DROP TABLE IF EXISTS `task`;

CREATE TABLE `task` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `task` varchar(50) NOT NULL,
  `taskdes` varchar(50) NOT NULL,
  `startdate` varchar(50) NOT NULL,
  `enddate` varchar(50) NOT NULL,
  `workercount` varchar(50) NOT NULL,
  `reputation` varchar(50) NOT NULL,
  `workermode` varchar(50) NOT NULL,
  `reqid` varchar(1000) NOT NULL,
  `selectedworker` varchar(1000) NOT NULL,
  `status` varchar(50) NOT NULL,
  `amount` varchar(344) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `task` */

insert  into `task`(`id`,`task`,`taskdes`,`startdate`,`enddate`,`workercount`,`reputation`,`workermode`,`reqid`,`selectedworker`,`status`,`amount`) values (1,'Writer','hdgsgffs','10/6/2020','11/10/2020','30','90','exper','4','','task posted',NULL),(2,'Programmer','ddfd','11/10/2020','11/11/2020','20','20','fresher','527bbb56e3970dd54f9fca3645049e1668b30febb70c6aa5730523b0c47a6af3',',94fbbc949203f3aefd570029b15dc91c1eff906b53393c68416f0732599c126','task posted','20'),(3,'Designer','Google Dogle','12/3/2020','14/3/2020','20','30','exper','63abb17fdd37edb557b465e0cd05ca4e968d8b8c8ac527a111f45b956405e033',',fe4c0587374171c39248e618f50e775e5790c5250faf09dba8f288345683b365','Task Complete','100');

/*Table structure for table `taskrequest` */

DROP TABLE IF EXISTS `taskrequest`;

CREATE TABLE `taskrequest` (
  `id` int(55) NOT NULL AUTO_INCREMENT,
  `tid` varchar(666) DEFAULT NULL,
  `uid` varchar(777) DEFAULT NULL,
  `status` varchar(77) DEFAULT NULL,
  `surl` varchar(566) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `taskrequest` */

insert  into `taskrequest`(`id`,`tid`,`uid`,`status`,`surl`) values (1,'2','94fbbc949203f3aefd570029b15dc91c1eff906b53393c68416f0732599c126','Task Assign',NULL),(3,'3','fe4c0587374171c39248e618f50e775e5790c5250faf09dba8f288345683b365','Task Evaluated','https://issues/4808');

/*Table structure for table `timelockprotocol` */

DROP TABLE IF EXISTS `timelockprotocol`;

CREATE TABLE `timelockprotocol` (
  `id` int(44) NOT NULL AUTO_INCREMENT,
  `uid` varchar(444) DEFAULT NULL,
  `amount` varchar(44) DEFAULT NULL,
  `holdamout` varchar(44) DEFAULT NULL,
  `status` varchar(44) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

/*Data for the table `timelockprotocol` */

insert  into `timelockprotocol`(`id`,`uid`,`amount`,`holdamout`,`status`) values (1,'c1c224b03cd9bc7b6a86d77f5dace40191766c485cd55dc48caf9ac873335d6f','1000','0','No Lock Payment'),(2,'527bbb56e3970dd54f9fca3645049e1668b30febb70c6aa5730523b0c47a6af3','940','60','Amount Holded'),(3,'ef59ad943a8e8ce4eb15968e7bd50cefa8f0236a60c92c8a78583c3402ce6a78','1000','0','No Lock Payment'),(4,'cbf9095c85e5b6448bed6aba4d1c5f09f2b49926cb80463e7c6976b5e8b15540','1000','0','No Lock Payment'),(5,'f2fdd58856e77152463d6183ffa198d69bb241ddf8378734c4d074f74544f4c8','1000','0','No Lock Payment'),(6,'e0aac11b76e6ba2e2850268d30529db9ee86750254cafa9aab7812bb0c59ee5','1000','0','No Lock Payment'),(7,'e6144337c993c7dc71d1b6142626c3f389b9f77aad9f0de2eb2e1ab2f7258eb9','1000','0','No Lock Payment'),(8,'94fbbc949203f3aefd570029b15dc91c1eff906b53393c68416f0732599c126','960','40','Amount Holded'),(9,'63abb17fdd37edb557b465e0cd05ca4e968d8b8c8ac527a111f45b956405e033','700','300','Amount Holded'),(10,'fe4c0587374171c39248e618f50e775e5790c5250faf09dba8f288345683b365','1700','0','Amount Released');

/*Table structure for table `worker` */

DROP TABLE IF EXISTS `worker`;

CREATE TABLE `worker` (
  `id` int(55) NOT NULL AUTO_INCREMENT,
  `uid` varchar(555) DEFAULT NULL,
  `work` varchar(555) DEFAULT NULL,
  `task` varchar(555) DEFAULT NULL,
  `reputation` varchar(555) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

/*Data for the table `worker` */

insert  into `worker`(`id`,`uid`,`work`,`task`,`reputation`) values (1,'ef59ad943a8e8ce4eb15968e7bd50cefa8f0236a60c92c8a78583c3402ce6a78','exper','Writer','50'),(2,'cbf9095c85e5b6448bed6aba4d1c5f09f2b49926cb80463e7c6976b5e8b15540','fresher','Programmer','50'),(3,'f2fdd58856e77152463d6183ffa198d69bb241ddf8378734c4d074f74544f4c8','exper','Programmer','50'),(4,'e0aac11b76e6ba2e2850268d30529db9ee86750254cafa9aab7812bb0c59ee5','fresher','Programmer','50'),(5,'94fbbc949203f3aefd570029b15dc91c1eff906b53393c68416f0732599c126','fresher','Programmer','50'),(6,'fe4c0587374171c39248e618f50e775e5790c5250faf09dba8f288345683b365','exper','Designer','70');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
