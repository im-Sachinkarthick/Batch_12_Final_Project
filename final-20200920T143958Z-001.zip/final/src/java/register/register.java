package register;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
/**
 *
 * @author Administrator
 */
@WebServlet(urlPatterns = {"/register"})
public class register extends HttpServlet {

     public static String getSHA(String input) 
    { 
  
        try { 
  
            // Static getInstance method is called with hashing SHA 
            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
  
            // digest() method called 
            // to calculate message digest of an input 
            // and return array of byte 
            byte[] messageDigest = md.digest(input.getBytes()); 
  
            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest); 
  
            // Convert message digest into hex value 
            String hashtext = no.toString(16); 
  
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
  
            return hashtext; 
        } 
  
        // For specifying wrong message digest algorithms 
        catch (NoSuchAlgorithmException e) { 
            System.out.println("Exception thrown"
                               + " for incorrect algorithm: " + e); 
  
            return null; 
        } 
    } 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();         /* TODO output your page here. You may use following sample code. */
    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         PrintWriter out = response.getWriter();  
        processRequest(request, response);
               String role=request.getParameter("role");
           String name=request.getParameter("username");
           String pwd=request.getParameter("pwd");
           String cpwd=request.getParameter("cpwd");
           String uniqueid=getSHA(name);
           String amt="1000";
         try {
if(!pwd.equalsIgnoreCase(cpwd))
{
     out.println("<script type=\"text/javascript\">");
                out.println("alert('Password and confirm Password Not similar');");
                out.println("location='register.jsp';");
                out.println("</script>");
}
             
             
             Dbconnection c=new Dbconnection();
             
           
           Connection con = c.connect();
         String sql = "Select * from register where name='" + name + "'";
    
          sqlquery kk = new sqlquery();
        ResultSet rs = kk.selectcheck(sql);
        if (rs.next()) {
            
              out.println("<script type=\"text/javascript\">");
                out.println("alert('Already User name Existed');");
                out.println("location='register.jsp';");
                out.println("</script>");
        }
        else
        {
           
           //String sql="insert into register values('"+name+"','"+email+"','"+username+"','"+password+"')";
         PreparedStatement ps=con.prepareStatement("insert into register(name,pwd,cpwd,role,unique1,amount)values(?,?,?,?,?,?)");
ps.setString(1,name);
ps.setString(2,pwd);ps.setString(3,cpwd);ps.setString(4,role);ps.setString(5,uniqueid);ps.setString(6,amt);
int x=ps.executeUpdate();
 ps=con.prepareStatement("insert into timelockprotocol(uid,amount,holdamout,status)values(?,?,?,?)");
ps.setString(1,uniqueid);
ps.setString(2,amt);ps.setString(3,"0");ps.setString(4,"No Lock Payment");
x=ps.executeUpdate();


if(x>0){
    out.println("<script type=\"text/javascript\">");
                out.println("alert('Registered Successfully');");
                out.println("location='index.jsp';");
                out.println("</script>");
 
}
else{
  out.println("<script type=\"text/javascript\">");
                out.println("alert('Error');");
                out.println("location='register.jsp';");
                out.println("</script>");
}
      
        }
         //  RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
         //  request.setAttribute("mssg","Registered Successfully" );
         //  rd.forward(request, response); 
        } catch (Exception e) {
           
            System.out.println(e);
        } 
  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
