package register;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Administrator
 */
@WebServlet(urlPatterns = {"/taskpost"})
public class taskpost extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          
         String taskmode=request.getParameter("taskmode");
           String workermode=request.getParameter("role");
           String reputation=request.getParameter("rep");
            String enddate=request.getParameter("ed");
            String startdate=request.getParameter("cd");
             String description=request.getParameter("des");
              String workercount=request.getParameter("cw");
           String prize=request.getParameter("amount");
              String selectedworkers="";
              String status="task posted";
        		HttpSession session=request.getSession(true);

          String uid= (String)session.getAttribute("name");
          
           String amount= (String)session.getAttribute("amount");
             Dbconnection c=new Dbconnection();
            
             
             String sql= "Select * from timelockprotocol where uid='"+uid+"' ";
String hol="0";
          sqlquery kk = new sqlquery();
        ResultSet rs = kk.selectcheck(sql);
        if (rs.next()) {
            
            hol=rs.getString("holdamout");
            
        }
        
       
             
           int aa=Integer.parseInt(prize)*3;
           Connection con = c.connect();
     
       if(Integer.parseInt(amount)>aa)  
       {
                 PreparedStatement ps=con.prepareStatement("insert into task(task,taskdes,startdate,enddate,workercount,reputation,workermode,reqid,selectedworker,status,amount)values(?,?,?,?,?,?,?,?,?,?,?)");
ps.setString(1,taskmode);
ps.setString(2,description);ps.setString(3,startdate);ps.setString(4,enddate);ps.setString(5,workercount);ps.setString(6,reputation);ps.setString(7,workermode);
ps.setString(8,uid);
        ps.setString(9,selectedworkers);
                ps.setString(10,status);
                   ps.setString(11,prize);
                
                
int x=ps.executeUpdate();
int amo=Integer.parseInt(amount)-aa;
 int jj=Integer.parseInt(hol)+aa;
   ps=con.prepareStatement("update timelockprotocol set amount=? , holdamout=?, status=? where uid=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(jj));ps.setString(3,"Amount Holded");ps.setString(4,uid);
  
                
 x=ps.executeUpdate();
 
   ps=con.prepareStatement("update register set amount=?  where unique1=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(uid));
        session .setAttribute("amount",amo);
                
 x=ps.executeUpdate();



if(x>0){
    
    out.println("<script type=\"text/javascript\">");
                out.println("alert('Task Posted Successfully');");
                out.println("location='reqtask.jsp';");
                out.println("</script>");
 
}
else{
  out.println("<script type=\"text/javascript\">");
                out.println("alert('Error');");
                out.println("location='reqtask.jsp';");
                out.println("</script>");
}
       
       }
       else
       {
             out.println("<script type=\"text/javascript\">");
                out.println("alert('Insufficient Banlance');");
                out.println("location='reqtask.jsp';");
                out.println("</script>");
       }
           //String sql="insert into register values('"+name+"','"+email+"','"+username+"','"+password+"')";
    
        
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(taskpost.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(taskpost.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        
        
        
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
