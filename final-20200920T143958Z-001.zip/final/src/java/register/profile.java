package register;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ISI-7
 */
@WebServlet(urlPatterns = {"/profile"})
public class profile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
          String taskmode=request.getParameter("taskmode");
           String workermode=request.getParameter("role");
           
           HttpSession session=request.getSession(true);

          String uid= (String)session.getAttribute("name");
          
               String sql= "Select * from worker where uid='"+uid+"' ";
  Dbconnection c=new Dbconnection();
             Connection con=c.connect();
          sqlquery kk = new sqlquery();
        ResultSet rs = kk.selectcheck(sql);
        if (rs.next()) {
            
        PreparedStatement ps=con.prepareStatement("update worker set work=? , task=? where uid=?"); 
ps.setString(1,String.valueOf(workermode));ps.setString(2,String.valueOf(taskmode));ps.setString(3,uid);
  
                
 int x=ps.executeUpdate();
 
              out.println("<script type=\"text/javascript\">");
                out.println("alert('Profile Update Successfully');");
                out.println("location='profile.jsp';");
                out.println("</script>");
        }
        else
        {
               PreparedStatement ps=con.prepareStatement("insert into worker(uid,work,task,reputation)values(?,?,?,?)");
ps.setString(1,uid);
ps.setString(2,workermode);ps.setString(3,taskmode);ps.setString(4,"50");
                
                
int x=ps.executeUpdate();
  out.println("<script type=\"text/javascript\">");
                out.println("alert('Profile Add Successfully');");
                out.println("location='profile.jsp';");
                out.println("</script>");
        }


        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(profile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(profile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
