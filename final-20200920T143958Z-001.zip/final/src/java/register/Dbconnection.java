package register;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
/**
 *
 * @author ISI-7
 */
public class Dbconnection {
      public  Connection connect(){
     Connection con = null;
     try{

	 //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         con=(Connection) DriverManager.getConnection
                        ("jdbc:mysql://localhost:3306/crowdbc","root","root");
         
        System.out.println("Connected");
      }catch(Exception e)
      {
          e.printStackTrace();
      }
     return con;
    }
     
}

