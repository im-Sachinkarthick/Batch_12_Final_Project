/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ISI-7
 */
public class evaluate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            HttpSession session=request.getSession(true);
            String task = (String) session.getAttribute("tiddd");
        String  taskrequestid=  (String) session.getAttribute("idd");
          String  uid=  (String) session.getAttribute("uid1");
          
         String  role= request.getParameter("role");
   
             String sql= "Select * from timelockprotocol where uid='"+uid+"' ";
String hol="0";
String amount="0";
          sqlquery kk = new sqlquery();
        ResultSet rs = kk.selectcheck(sql);
        if (rs.next()) {
            
            hol=rs.getString("holdamout");
            amount=rs.getString("amount");
            
        }
           sql= "Select * from task where id='"+task+"' ";
String pamount="0";
    String selectedworker="0";   
     String count="0"; 
     String tids="";
         rs = kk.selectcheck(sql);
        if (rs.next()) {
            
            pamount=rs.getString("amount");
            selectedworker=rs.getString(10);
            count=rs.getString(6);
            tids=rs.getString("reqid");
        }
        
        
  sql= "Select * from worker where uid='"+uid+"' ";
String reputation="0";
 
         rs = kk.selectcheck(sql);
        if (rs.next()) {
            
            reputation=rs.getString("reputation");
         
        }
        
      String kkl[]= selectedworker.split(",");
      
          
           int aa=Integer.parseInt(pamount);
             Dbconnection c=new Dbconnection();
             Connection con=c.connect();
     
       
           if(role.equalsIgnoreCase("good"))
           {
           selectedworker=selectedworker+","+uid;
           int rep=Integer.parseInt(reputation)+10;
int amo=Integer.parseInt(amount)+aa+aa;
 int jj=Integer.parseInt(hol)-(aa);
 PreparedStatement   ps=con.prepareStatement("update timelockprotocol set amount=? , holdamout=?, status=? where uid=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(jj));ps.setString(3,"Amount Holded");ps.setString(4,uid);
  
                
int x=ps.executeUpdate();
 
   ps=con.prepareStatement("update register set amount=?  where unique1=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(uid));
    
 x=ps.executeUpdate();
 
   ps=con.prepareStatement("update task set status=?  where id=?"); 
ps.setString(1,String.valueOf("Task Complete"));ps.setString(2,String.valueOf(task));
      
          x=ps.executeUpdate();
 
   ps=con.prepareStatement("update worker set reputation=?  where uid=?"); 
ps.setString(1,String.valueOf(rep));ps.setString(2,String.valueOf(uid));       
 x=ps.executeUpdate();
  ps=con.prepareStatement("update taskrequest set status=?  where id=?"); 
ps.setString(1,String.valueOf("Task Evaluated"));ps.setString(2,String.valueOf(taskrequestid));
    
 x=ps.executeUpdate();



if(x>0){
    
    out.println("<script type=\"text/javascript\">");
                out.println("alert('Work Evaluate Successfully');");
                out.println("location='Miner.jsp';");
                out.println("</script>");
 
}
else{
  out.println("<script type=\"text/javascript\">");
                out.println("alert('Error');");
                out.println("location='Miner.jsp';");
                out.println("</script>");
}
       
       }
           else
           {
             
               
               
                selectedworker=selectedworker+","+uid;
           int rep=Integer.parseInt(reputation)+10;
int amo=Integer.parseInt(amount)+aa;
 int jj=Integer.parseInt(hol)-(aa);
 PreparedStatement   ps=con.prepareStatement("update timelockprotocol set amount=? , holdamout=?, status=? where uid=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(jj));ps.setString(3,"Amount Released");ps.setString(4,uid);
  
                
int x=ps.executeUpdate();
 
   ps=con.prepareStatement("update register set amount=?  where unique1=?"); 
ps.setString(1,String.valueOf(amo));ps.setString(2,String.valueOf(uid));
    
 x=ps.executeUpdate();
 
   ps=con.prepareStatement("update task set status=?  where id=?"); 
ps.setString(1,String.valueOf("Task Complete"));ps.setString(2,String.valueOf(task));
      
          x=ps.executeUpdate();
 
 
  ps=con.prepareStatement("update  taskrequest set status=?  where id=?"); 
ps.setString(1,String.valueOf("Task Evaluated"));ps.setString(2,String.valueOf(taskrequestid));
    
 x=ps.executeUpdate();
               
               
             out.println("<script type=\"text/javascript\">");
                out.println("alert('Sucessfully Evaluated');");
                out.println("location='Miner.jsp';");
                out.println("</script>");
           }
       }
     
           //String sql="insert into register values('"+name+"','"+email+"','"+username+"','"+password+"')";
    
        
    }
         
         

      

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(evaluate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(evaluate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
