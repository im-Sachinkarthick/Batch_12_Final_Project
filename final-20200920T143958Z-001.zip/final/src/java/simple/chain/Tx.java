package simple.chain;

public interface Tx {
	
	   abstract String hash();

}
