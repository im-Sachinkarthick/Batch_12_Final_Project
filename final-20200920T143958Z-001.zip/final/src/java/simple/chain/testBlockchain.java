/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple.chain;

import com.google.gson.GsonBuilder;
import java.util.List;

/**
 *
 * @author ISI-7
 */
public class testBlockchain {
    public static void main(String args[])
    {
   
       block();
    }
    public static void block()
    {
         SimpleBlockchain<Transaction> chain1 = new SimpleBlockchain<Transaction>();

		chain1.add(new Transaction("9000"));

	

		System.out.println(String.format("Chain 1 Hash: %s", chain1.getHead().getHash()));
		

		

		System.out.println("Current Chain Head Transactions: ");
		for (Block block : chain1.chain) {
                    
                                System.out.println(block.getHash());
                   System.out.println(block.getPreviousHash());
                   System.out.println(block.timeStamp);
                     System.out.println(block.getIndex());
                      System.out.println(block.getTransactions());
			for (Object tx : block.getTransactions()) {
				System.out.println("\t" + tx);
			}
		}

		// Block Merkle root should equal root hash in Merkle Tree computed from
		// block transactions
		Block headBlock = chain1.getHead();
		List<Transaction> merkleTree = headBlock.merkleTree();
		if(headBlock.getMerkleRoot().equals(merkleTree.get(merkleTree.size() - 1)));

		// Validate block chain
		if(chain1.validate());
		System.out.println(String.format("Chain is Valid: %s", chain1.validate()));
                String blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(chain1);
		System.out.println("\nThe block chain: ");
		System.out.println(blockchainJson);
                
        
                
                
    }
    public static void hashtree()
            
    {
        SimpleBlockchain<Transaction> chain1 = new SimpleBlockchain<Transaction>();

		chain1.add(new Transaction("A")).add(new Transaction("B")).add(new Transaction("C")).add(new Transaction("D"));

		// get a block in chain
		Block<Transaction> block = chain1.getHead();

		System.out.println("Merkle Hash tree :" + block.merkleTree());

		// get a transaction from block
		Transaction tx = block.getTransactions().get(0);

		// see if block transactions are valid, they should be
		block.transasctionsValid();
		if(block.transasctionsValid());

		// mutate the data of a transaction
		tx.setValue("Z");

		// block should no longer be valid, blocks MerkleRoot does not match computed merkle tree of transactions
		if(block.transasctionsValid());

    }
    public static void build()
    {
        SimpleBlockchain<Transaction> chain = new SimpleBlockchain<Transaction>();

		// Respresents a proof of work miner
		// Creates
		Miner miner = new Miner(chain);

		// This represents transactions being created by a network
		for (int i = 0; i < 30; i++) {
			miner.mine(new Transaction("" + i));
		}

		System.out.println("Number of Blocks Mined = " + chain.getChain().size());
		if(chain.getChain().size() == 3);
    }
    
}
